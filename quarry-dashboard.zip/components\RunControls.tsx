"use client";

import { useState } from "react";

export default function RunControls({
  onRun,
}: {
  onRun: (mode: "real" | "simulate", scenario?: "no_change" | "inside" | "outside") => Promise<void>;
}) {
  const [loading, setLoading] = useState<string | null>(null);

  const run = async (
    label: string,
    mode: "real" | "simulate",
    scenario?: "no_change" | "inside" | "outside"
  ) => {
    setLoading(label);
    try {
      await onRun(mode, scenario);
    } finally {
      setLoading(null);
    }
  };

  const btnClass =
    "inline-flex items-center justify-center rounded-lg border border-white/10 bg-slate-900/80 px-3 py-2 text-[11px] font-medium text-slate-200 transition hover:border-emerald-400/40 hover:text-white disabled:cursor-not-allowed disabled:opacity-50";

  return (
    <div className="flex flex-wrap items-center gap-2 rounded-xl border border-white/10 bg-slate-900/70 p-2">
      <button className={`${btnClass} border-emerald-500/30 bg-emerald-500/10 text-emerald-300`} disabled={!!loading} onClick={() => run("real", "real")}>
        {loading === "real" ? "Running…" : "Run Analysis"}
      </button>

      <div className="flex items-center gap-2 border-l border-white/10 pl-2">
        <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-400">Scenario</span>
        <button className={btnClass} disabled={!!loading} onClick={() => run("no_change", "simulate", "no_change")}>
          {loading === "no_change" ? "…" : "No Change"}
        </button>
        <button className={btnClass} disabled={!!loading} onClick={() => run("inside", "simulate", "inside")}>
          {loading === "inside" ? "…" : "Inside"}
        </button>
        <button className={btnClass} disabled={!!loading} onClick={() => run("outside", "simulate", "outside")}>
          {loading === "outside" ? "…" : "Outside"}
        </button>
      </div>
    </div>
  );
}
